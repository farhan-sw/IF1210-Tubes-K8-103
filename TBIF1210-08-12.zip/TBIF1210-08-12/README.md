# IF1210-Tubes-K8-103
Tugas Besar Kelompok 103 Kelas 8 Dasar Pemograman

# Tugas Besar

## Spesifikasi

https://docs.google.com/document/d/1aMDXJNT-S1K2K1B-zVPfJyavmi3QwR5FRxJgObbX4d0/edit

## Pedoman

https://docs.google.com/document/d/12G2NKudDz2mkpIan3ETCke32jStL4ISYr1IkVeYTsWk/edit

## Link Kelompok

https://docs.google.com/spreadsheets/d/e/2PACX-1vRuj5knbDL3-J4r-t3RjftColSxuOVA0FkTIBSEZSjjDGSi5CjWJuTiYDfntrNA9F5FgPwTofIgqJrg/pubhtml

## Link QNA

https://docs.google.com/spreadsheets/d/150tM5KS0iX52rFiLw_hoX_iwHH9HEJXwMlTtyiYbMos/edit#gid=345669090

## Langkah Git

### Cek Git
> git --version

### Clone Repo
> git clone https://github.com/farhan-sw/IF1210-Tubes-K8-103.git

### Update Perubahan
> git add .

> git commit -m "Penambahan fungsi 1"

### Upload
> git push

### Download
> git pull