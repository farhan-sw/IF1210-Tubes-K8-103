# Fungsi Logout                  logout(isLogin : Bool) -> Bool
def logout(isLogin : bool):
# Function logout (isLogin : Boolean) -> Boolean 
# Fungsi akan menerima input berupa Boolean yang bernilai True dan mengembalikan nilai False daru Boolean tersebut

# KAMUS LOKAL 
    isLogin : bool

# ALGORITMA
    return not isLogin